// Nexora Mock Database

const CATEGORIES = [
  { id: 'electronics', name: 'Electronics', icon: 'ri-cpu-line', color: '#8B5CF6' },
  { id: 'fashion', name: 'Fashion', icon: 'ri-t-shirt-line', color: '#EC4899' },
  { id: 'beauty', name: 'Beauty', icon: 'ri-sparkles-line', color: '#F43F5E' },
  { id: 'home', name: 'Home', icon: 'ri-home-4-line', color: '#10B981' },
  { id: 'gaming', name: 'Gaming', icon: 'ri-gamepad-line', color: '#3B82F6' },
  { id: 'groceries', name: 'Groceries', icon: 'ri-shopping-basket-2-line', color: '#F59E0B' },
  { id: 'sports', name: 'Sports', icon: 'ri-run-line', color: '#06B6D4' },
  { id: 'automotive', name: 'Automotive', icon: 'ri-car-line', color: '#64748B' }
];

const PRODUCTS = [
  // ELECTRONICS
  {
    id: 'elec-1',
    name: 'AeroSound Pro ANC Headphones',
    category: 'electronics',
    price: 249.99,
    discount: 20, // 20% off
    rating: 4.8,
    reviewsCount: 142,
    stock: 24,
    description: 'Experience pure acoustic bliss with the AeroSound Pro. Featuring Hybrid Active Noise Cancellation, 40-hour battery life, and spatial audio support for an immersive theater-like experience.',
    images: [
      'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&auto=format&fit=crop&q=60',
      'https://images.unsplash.com/photo-1484704849700-f032a568e944?w=800&auto=format&fit=crop&q=60',
      'https://images.unsplash.com/photo-1583394838336-acd977736f90?w=800&auto=format&fit=crop&q=60'
    ],
    videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-headphones-lying-on-a-surface-40284-large.mp4',
    isFlashDeal: true,
    flashDealClaimed: 65, // % claimed
    isTrending: true,
    isNewArrival: false,
    seller: {
      name: 'AeroSound Official Store',
      rating: 4.9,
      responseRate: '98%',
      joined: '2 years ago'
    },
    specs: {
      'Driver Size': '40mm Dynamic',
      'Battery Life': 'Up to 40 Hours (ANC On)',
      'Connectivity': 'Bluetooth 5.2, AUX',
      'Charging': 'USB-C Fast Charging (10 mins = 5 hrs)'
    },
    reviews: [
      { user: 'Sahan K.', rating: 5, date: '2026-07-10', comment: 'Sound quality is absolute top tier. Noise cancellation works perfectly in busy coffee shops.', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Sahan' },
      { user: 'Nisansala P.', rating: 4, date: '2026-06-28', comment: 'Very comfortable for long hours. Battery lasts forever! Highly recommended.', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Nisansala' }
    ]
  },
  {
    id: 'elec-2',
    name: 'VividPixel Smart Watch Ultra',
    category: 'electronics',
    price: 189.99,
    discount: 15,
    rating: 4.6,
    reviewsCount: 88,
    stock: 12,
    description: 'Track your health and stay connected with the VividPixel Smart Watch Ultra. Built with an aerospace-grade titanium case, real-time heart rate monitoring, sleep analysis, and multi-sport tracking.',
    images: [
      'https://images.unsplash.com/photo-1542496658-e33a6d0d50f6?w=800&auto=format&fit=crop&q=60',
      'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800&auto=format&fit=crop&q=60'
    ],
    videoUrl: '',
    isFlashDeal: false,
    isTrending: false,
    isNewArrival: true,
    seller: {
      name: 'VividPixel Tech',
      rating: 4.7,
      responseRate: '95%',
      joined: '1 year ago'
    },
    specs: {
      'Display': '1.96-inch AMOLED Touchscreen',
      'Battery Life': 'Up to 7 Days (Typical Use)',
      'Water Resistance': '5ATM (Up to 50m)',
      'Sensors': 'ECG, SpO2, Heart Rate, Accelerometer'
    },
    reviews: [
      { user: 'Dumindu S.', rating: 5, date: '2026-07-18', comment: 'The display is super bright even in direct sunlight. Fitness tracking is highly accurate.', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Dumindu' }
    ]
  },

  // FASHION
  {
    id: 'fash-1',
    name: 'UrbanFit Classic Denim Jacket',
    category: 'fashion',
    price: 79.99,
    discount: 30,
    rating: 4.5,
    reviewsCount: 204,
    stock: 45,
    description: 'Timeless style meets modern comfort. Crafted from 100% premium cotton denim, featuring a relaxed fit, button closures, and classic chest pockets. Perfect for layering in any season.',
    images: [
      'https://images.unsplash.com/photo-1576995853123-5a10305d93c0?w=800&auto=format&fit=crop&q=60',
      'https://images.unsplash.com/photo-1611312449412-6cefac5dc3e4?w=800&auto=format&fit=crop&q=60'
    ],
    videoUrl: '',
    isFlashDeal: true,
    flashDealClaimed: 42,
    isTrending: true,
    isNewArrival: false,
    seller: {
      name: 'UrbanFit Apparel',
      rating: 4.6,
      responseRate: '92%',
      joined: '3 years ago'
    },
    specs: {
      'Material': '100% Cotton Denim',
      'Fit': 'Regular / Relaxed Fit',
      'Care': 'Machine wash cold, tumble dry low',
      'Pockets': '4-Pocket Design'
    },
    reviews: [
      { user: 'Malith D.', rating: 5, date: '2026-07-02', comment: 'True to size and very comfortable. Heavy denim but soft to touch.', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Malith' }
    ]
  },
  {
    id: 'fash-2',
    name: 'BreezeWalk Lightweight Running Sneakers',
    category: 'fashion',
    price: 95.00,
    discount: 10,
    rating: 4.7,
    reviewsCount: 115,
    stock: 18,
    description: 'Engineered for maximum speed and cushioning. The BreezeWalk sneakers feature a breathable mesh upper, cloud-like foam midsole, and durable rubber traction pods for responsive strides.',
    images: [
      'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800&auto=format&fit=crop&q=60',
      'https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?w=800&auto=format&fit=crop&q=60'
    ],
    videoUrl: '',
    isFlashDeal: false,
    isTrending: true,
    isNewArrival: true,
    seller: {
      name: 'Breeze Sports Co.',
      rating: 4.8,
      responseRate: '99%',
      joined: '4 years ago'
    },
    specs: {
      'Upper': 'Engineered Mesh (Recycled Polyester)',
      'Midsole': 'CloudFoam cushioning',
      'Weight': '245g (Size 9)',
      'Drop': '8mm'
    },
    reviews: [
      { user: 'Kasun T.', rating: 5, date: '2026-07-15', comment: 'Extremely lightweight. Feels like walking on air. Love the design!', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Kasun' }
    ]
  },

  // BEAUTY
  {
    id: 'beau-1',
    name: 'GlowHydra Vitamin C Radiance Serum',
    category: 'beauty',
    price: 34.99,
    discount: 25,
    rating: 4.9,
    reviewsCount: 310,
    stock: 50,
    description: 'Reveal glowing skin with our highly stable 15% Vitamin C serum. Enhanced with Hyaluronic Acid and Ferulic Acid to brighten dark spots, refine skin texture, and protect against environmental stressors.',
    images: [
      'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?w=800&auto=format&fit=crop&q=60',
      'https://images.unsplash.com/photo-1601049541289-9b1b7bbbfe19?w=800&auto=format&fit=crop&q=60'
    ],
    videoUrl: '',
    isFlashDeal: true,
    flashDealClaimed: 89,
    isTrending: true,
    isNewArrival: false,
    seller: {
      name: 'GlowLabs Cosmetics',
      rating: 4.9,
      responseRate: '97%',
      joined: '1 year ago'
    },
    specs: {
      'Skin Type': 'All Skin Types (Dermatologist Tested)',
      'Key Ingredients': '15% L-Ascorbic Acid, Vitamin E, Hyaluronic Acid',
      'Volume': '30ml / 1.0 fl. oz.',
      'Cruelty Free': 'Yes (Leaping Bunny Certified)'
    },
    reviews: [
      { user: 'Fathima R.', rating: 5, date: '2026-07-20', comment: 'My hyperpigmentation is literally disappearing. Best Vitamin C I have ever used.', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Fathima' }
    ]
  },

  // HOME
  {
    id: 'home-1',
    name: 'AromaSphere Ultrasonic Oil Diffuser',
    category: 'home',
    price: 45.00,
    discount: 15,
    rating: 4.4,
    reviewsCount: 76,
    stock: 30,
    description: 'Transform your room into a peaceful sanctuary. The AromaSphere features ultrasonic technology, a 300ml capacity for 8 hours of mist, 7 rotating LED mood lights, and auto-shutoff security.',
    images: [
      'https://images.unsplash.com/photo-1608571423902-eed4a5ad8108?w=800&auto=format&fit=crop&q=60',
      'https://images.unsplash.com/photo-1519641471654-76ce0107ad1b?w=800&auto=format&fit=crop&q=60'
    ],
    videoUrl: '',
    isFlashDeal: false,
    isTrending: false,
    isNewArrival: true,
    seller: {
      name: 'ZenHome Products',
      rating: 4.5,
      responseRate: '91%',
      joined: '6 months ago'
    },
    specs: {
      'Water Capacity': '300ml',
      'Coverage Area': 'Up to 250 sq ft',
      'Timer settings': '1H / 3H / 6H / ON',
      'Noise Level': 'Below 25dB'
    },
    reviews: [
      { user: 'Piyal E.', rating: 4, date: '2026-07-12', comment: 'Very quiet and the lights are really relaxing. Helps me sleep at night.', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Piyal' }
    ]
  },

  // GAMING
  {
    id: 'game-1',
    name: 'StrikeX RGB Mechanical Gaming Keyboard',
    category: 'gaming',
    price: 129.99,
    discount: 35,
    rating: 4.8,
    reviewsCount: 198,
    stock: 15,
    description: 'Dominate the battlefield with custom mechanical switches. The StrikeX features red linear switches, per-key RGB backlighting, custom software profile setups, and a premium brushed aluminum top frame.',
    images: [
      'https://images.unsplash.com/photo-1587829741301-dc798b83add3?w=800&auto=format&fit=crop&q=60',
      'https://images.unsplash.com/photo-1618384887929-16ec33fab9ef?w=800&auto=format&fit=crop&q=60'
    ],
    videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-typing-on-a-luminous-gaming-keyboard-40618-large.mp4',
    isFlashDeal: true,
    flashDealClaimed: 78,
    isTrending: true,
    isNewArrival: false,
    seller: {
      name: 'StrikeX Gaming Gear',
      rating: 4.8,
      responseRate: '96%',
      joined: '3 years ago'
    },
    specs: {
      'Switches': 'StrikeX Linear Red Switches',
      'Layout': 'Tenkeyless (80%)',
      'Keycaps': 'Double-shot PBT Keycaps',
      'RGB': '16.8M Colors, Per-key Customizable'
    },
    reviews: [
      { user: 'Rushan M.', rating: 5, date: '2026-07-22', comment: 'Super fast switches, beautiful RGB lighting. The build quality feels heavy and premium.', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Rushan' }
    ]
  },

  // GROCERIES
  {
    id: 'groc-1',
    name: 'NutraOrga Premium Organic Matcha Powder',
    category: 'groceries',
    price: 24.99,
    discount: 5,
    rating: 4.7,
    reviewsCount: 65,
    stock: 100,
    description: '100% Ceremonial Grade organic green tea powder sourced from Uji, Japan. Rich in antioxidants and amino acids, providing a calm, long-lasting energy boost without the coffee crash.',
    images: [
      'https://images.unsplash.com/photo-1536256263959-770b48d82b0a?w=800&auto=format&fit=crop&q=60',
      'https://images.unsplash.com/photo-1582793988951-9aed5509eb97?w=800&auto=format&fit=crop&q=60'
    ],
    videoUrl: '',
    isFlashDeal: false,
    isTrending: true,
    isNewArrival: false,
    seller: {
      name: 'NutraOrga Superfoods',
      rating: 4.8,
      responseRate: '94%',
      joined: '2 years ago'
    },
    specs: {
      'Weight': '100g / 3.5oz',
      'Grade': 'Ceremonial Grade A',
      'Origin': 'Uji, Kyoto, Japan',
      'Certifications': 'USDA Organic, Non-GMO Project Verified'
    },
    reviews: [
      { user: 'Dilani F.', rating: 5, date: '2026-07-05', comment: 'Incredibly smooth flavor. No bitterness at all! Makes the perfect matcha lattes.', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Dilani' }
    ]
  },

  // SPORTS
  {
    id: 'spor-1',
    name: 'HydroShield Insulated Water Bottle',
    category: 'sports',
    price: 29.99,
    discount: 15,
    rating: 4.6,
    reviewsCount: 154,
    stock: 60,
    description: 'Keep your drinks ice cold for up to 24 hours or piping hot for up to 12. Built with double-wall stainless steel, custom powder-coat grip, and a leakproof straw lid.',
    images: [
      'https://images.unsplash.com/photo-1602143407151-7111542de6e8?w=800&auto=format&fit=crop&q=60',
      'https://images.unsplash.com/photo-1523362628745-0c100150b504?w=800&auto=format&fit=crop&q=60'
    ],
    videoUrl: '',
    isFlashDeal: false,
    isTrending: false,
    isNewArrival: false,
    seller: {
      name: 'HydroShield Gear',
      rating: 4.7,
      responseRate: '93%',
      joined: '5 years ago'
    },
    specs: {
      'Capacity': '32 oz (946ml)',
      'Material': '18/8 Food-Grade Stainless Steel',
      'Insulation': 'Double-Wall Vacuum Sealed',
      'BPA Free': 'Yes'
    },
    reviews: [
      { user: 'Nuwan W.', rating: 4, date: '2026-07-11', comment: 'Keeps water cold all day during my long cycling sessions. Lid is totally leakproof.', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Nuwan' }
    ]
  },

  // AUTOMOTIVE
  {
    id: 'auto-1',
    name: 'RoadLens Pro 4K Dash Cam',
    category: 'automotive',
    price: 159.99,
    discount: 25,
    rating: 4.7,
    reviewsCount: 92,
    stock: 22,
    description: 'Record your journeys in absolute clarity. The RoadLens Pro records in Ultra HD 4K, features night vision technology, a 170-degree ultra-wide angle view, G-sensor collision capture, and built-in WiFi.',
    images: [
      'https://images.unsplash.com/photo-1563720223185-11003d516935?w=800&auto=format&fit=crop&q=60',
      'https://images.unsplash.com/photo-1549317661-bd32c8ce0db2?w=800&auto=format&fit=crop&q=60'
    ],
    videoUrl: '',
    isFlashDeal: true,
    flashDealClaimed: 50,
    isTrending: false,
    isNewArrival: true,
    seller: {
      name: 'RoadLens Electronics',
      rating: 4.6,
      responseRate: '90%',
      joined: '1 year ago'
    },
    specs: {
      'Video Resolution': 'Ultra HD 4K (3840x2160) @30fps',
      'Viewing Angle': '170 Degrees',
      'Storage': 'Supports microSD card up to 256GB',
      'App Control': 'Yes (RoadLens App for iOS/Android)'
    },
    reviews: [
      { user: 'Shenal L.', rating: 5, date: '2026-07-16', comment: 'Extremely clear video quality. License plates are easily readable even at night.', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Shenal' }
    ]
  },

  // ADDING MORE FOR SEAMLESS PAGES & DIVERSITY
  {
    id: 'elec-3',
    name: 'FlexSound Wireless Bluetooth Speaker',
    category: 'electronics',
    price: 59.99,
    discount: 10,
    rating: 4.5,
    reviewsCount: 67,
    stock: 40,
    description: 'Compact size, monstrous sound. Featuring IPX7 waterproof rating, 24-hour playtime, and 360-degree surrounding sound. Connect two speakers together for absolute stereo performance.',
    images: [
      'https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=800&auto=format&fit=crop&q=60'
    ],
    videoUrl: '',
    isFlashDeal: false,
    isTrending: false,
    isNewArrival: false,
    seller: {
      name: 'FlexSound Audio',
      rating: 4.8,
      responseRate: '97%',
      joined: '3 years ago'
    },
    specs: {
      'Output Power': '20W RMS',
      'Waterproof Rating': 'IPX7 Waterproof',
      'Playtime': 'Up to 24 Hours',
      'Bluetooth Range': '66 feet (20 meters)'
    },
    reviews: [
      { user: 'Kavinda R.', rating: 4, date: '2026-07-04', comment: 'Deep bass and clear highs. Survived a drop in the pool without issues.', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Kavinda' }
    ]
  },
  {
    id: 'fash-3',
    name: 'LuxSoft Oversized Fleece Hoodie',
    category: 'fashion',
    price: 49.99,
    discount: 15,
    rating: 4.8,
    reviewsCount: 312,
    stock: 80,
    description: 'Wrap yourself in absolute coziness. This premium oversized hoodie is made from double-brushed organic fleece, featuring a double-lined hood and drop-shoulder design.',
    images: [
      'https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=800&auto=format&fit=crop&q=60'
    ],
    videoUrl: '',
    isFlashDeal: false,
    isTrending: true,
    isNewArrival: false,
    seller: {
      name: 'UrbanFit Apparel',
      rating: 4.6,
      responseRate: '92%',
      joined: '3 years ago'
    },
    specs: {
      'Material': '80% Organic Cotton, 20% Recycled Polyester',
      'Weight': '400 GSM Heavyweight Fleece',
      'Fit': 'Oversized Silhouette',
      'Unisex': 'Yes'
    },
    reviews: [
      { user: 'Minoli W.', rating: 5, date: '2026-07-21', comment: 'Literally the softest hoodie I own. Ordering another color immediately.', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Minoli' }
    ]
  },
  {
    id: 'beau-2',
    name: 'VelvetLips Matte Liquid Lipstick Set',
    category: 'beauty',
    price: 29.99,
    discount: 20,
    rating: 4.7,
    reviewsCount: 88,
    stock: 25,
    description: 'Our award-winning liquid lipsticks feature an ultra-matte, transfer-proof finish with a weightless, hydrating feel. Pack of 4 curated signature shades.',
    images: [
      'https://images.unsplash.com/photo-1586495777744-4413f21062fa?w=800&auto=format&fit=crop&q=60'
    ],
    videoUrl: '',
    isFlashDeal: false,
    isTrending: false,
    isNewArrival: true,
    seller: {
      name: 'GlowLabs Cosmetics',
      rating: 4.9,
      responseRate: '97%',
      joined: '1 year ago'
    },
    specs: {
      'Finish': 'Ultra-Matte, Transfer-Proof',
      'Set Contains': '4 liquid lipstick shades (3.5ml each)',
      'Wear Time': 'Up to 16 Hours',
      'Vegan': 'Yes'
    },
    reviews: [
      { user: 'Senuri G.', rating: 5, date: '2026-06-15', comment: 'Does not dry out the lips. The red shade is absolutely beautiful.', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Senuri' }
    ]
  },
  {
    id: 'game-2',
    name: 'Vortex Wireless Pro Controller',
    category: 'gaming',
    price: 69.99,
    discount: 10,
    rating: 4.6,
    reviewsCount: 140,
    stock: 19,
    description: 'Designed for precision and ultimate control. Features drift-resistant Hall Effect joysticks, tactile clicky face buttons, dual rumble motors, and customizable back paddles.',
    images: [
      'https://images.unsplash.com/photo-1600080972464-8e5f35f63d08?w=800&auto=format&fit=crop&q=60'
    ],
    videoUrl: '',
    isFlashDeal: false,
    isTrending: true,
    isNewArrival: false,
    seller: {
      name: 'Vortex Gaming Store',
      rating: 4.7,
      responseRate: '95%',
      joined: '2 years ago'
    },
    specs: {
      'Compatible Platforms': 'PC, Nintendo Switch, Android, iOS',
      'Joysticks': 'Hall Effect Magnetic (No Drift)',
      'Battery': '800mAh Rechargeable (Up to 15 Hours)',
      'Connection': '2.4GHz Wireless, Bluetooth, USB-C'
    },
    reviews: [
      { user: 'Janith B.', rating: 5, date: '2026-07-09', comment: 'Hall effect sticks are so responsive. Feels way better than the stock controller.', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Janith' }
    ]
  }
];

// Helper to filter items dynamically based on lists
const getFlashDeals = () => PRODUCTS.filter(p => p.isFlashDeal);
const getTrendingProducts = () => PRODUCTS.filter(p => p.isTrending);
const getNewArrivals = () => PRODUCTS.filter(p => p.isNewArrival);
const getRecommendedProducts = () => PRODUCTS.filter(p => !p.isFlashDeal && p.rating >= 4.6);
const getProductsByCategory = (catId) => PRODUCTS.filter(p => p.category === catId);
const getProductById = (id) => PRODUCTS.find(p => p.id === id);

// Export for app modules
window.NexoraDB = {
  CATEGORIES,
  PRODUCTS,
  getFlashDeals,
  getTrendingProducts,
  getNewArrivals,
  getRecommendedProducts,
  getProductsByCategory,
  getProductById
};

// Nexora Core Application Logic

// App State
const state = {
  cart: [],
  wishlist: new Set(),
  orders: [],
  notifications: [
    { id: 'n-1', title: 'Welcome to Nexora!', body: 'Explore top brands from Daraz, Temu, and Alibaba in one single premium experience.', type: 'promo', time: '1 hour ago', unread: true },
    { id: 'n-2', title: 'Super Flash Sale Active!', body: 'Use coupon code NEXORA10 to get 10% off on all headphones and gaming gear.', type: 'promo', time: '2 hours ago', unread: true }
  ],
  user: {
    name: 'Faizan Ahamed',
    email: 'faizz@nexora.com',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Faizz',
    address: 'No. 45, Flower Road, Colombo 07',
    paymentMethod: 'Card'
  },
  activeTab: 'home',
  currentTheme: 'dark',
  language: 'English',
  currency: 'LKR', // Default to LKR
  exchangeRate: 300, // 1 USD = 300 LKR
  selectedProduct: null,
  activeProductTab: 'description',
  activeDetailImageIndex: 0,
  appliedCoupon: null
};

// Available Coupons
const COUPONS = {
  'NEXORA10': { type: 'percent', value: 10 },
  'SAVE500': { type: 'flat', value: 500 }, // Flat LKR 500 off
  'FREEFLY': { type: 'percent', value: 100 } // Free for fun
};

// Initialize Application
document.addEventListener('DOMContentLoaded', () => {
  initTheme();
  initRouter();
  initSearch();
  initFlashTimer();
  initSimulatedOrderUpdates();
  renderAll();
  
  // Register service worker if available
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('./service-worker.js')
      .then(reg => console.log('Service Worker Registered!', reg))
      .catch(err => console.error('Service Worker Registry Failed', err));
  }
});

// Toast Notification Manager
function showToast(message, type = 'info') {
  const container = document.getElementById('toast-container');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  
  let icon = 'ri-info-card-line';
  if (type === 'success') icon = 'ri-checkbox-circle-line';
  if (type === 'warning') icon = 'ri-error-warning-line';
  if (type === 'danger') icon = 'ri-close-circle-line';

  toast.innerHTML = `
    <i class="${icon}"></i>
    <span>${message}</span>
  `;

  container.appendChild(toast);

  // Auto remove
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(-10px)';
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}

// Format Price Helper
function formatPrice(amountUSD) {
  if (state.currency === 'LKR') {
    const amountLKR = amountUSD * state.exchangeRate;
    return `Rs. ${amountLKR.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  }
  return `$${amountUSD.toFixed(2)}`;
}

// Router & Tabs navigation
function initRouter() {
  const navItems = document.querySelectorAll('.bottom-nav .nav-item');
  navItems.forEach(item => {
    item.addEventListener('click', (e) => {
      e.preventDefault();
      const tab = item.getAttribute('data-tab');
      if (tab) {
        switchTab(tab);
      }
    });
  });
  
  // Back buttons handling
  document.querySelectorAll('.back-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      // Close open modals/detail overlays
      closeAllModals();
    });
  });
}

function switchTab(tabId) {
  state.activeTab = tabId;
  
  // Update Bottom Nav UI
  document.querySelectorAll('.bottom-nav .nav-item').forEach(item => {
    if (item.getAttribute('data-tab') === tabId) {
      item.classList.add('active');
    } else {
      item.classList.remove('active');
    }
  });

  // Update Screens Visibility
  document.querySelectorAll('.tab-screen').forEach(screen => {
    if (screen.id === `${tabId}-screen`) {
      screen.classList.add('active');
    } else {
      screen.classList.remove('active');
    }
  });

  // Specific tab render updates
  if (tabId === 'home') {
    renderHomeProducts();
  } else if (tabId === 'cart') {
    renderCart();
  } else if (tabId === 'wishlist') {
    renderWishlist();
  } else if (tabId === 'profile') {
    renderProfile();
  } else if (tabId === 'search') {
    renderSearchScreen();
  }

  // Scroll to top
  document.querySelector('.app-content').scrollTop = 0;
  closeAllModals();
}

function closeAllModals() {
  document.querySelectorAll('.modal-sheet').forEach(sheet => {
    sheet.classList.remove('active');
  });
  document.querySelector('.video-overlay').classList.remove('active');
  const video = document.querySelector('.video-overlay video');
  if (video) video.pause();
}

// Theme Manager
function initTheme() {
  const savedTheme = localStorage.getItem('nexora-theme') || 'dark';
  state.currentTheme = savedTheme;
  applyTheme(savedTheme);
}

function applyTheme(theme) {
  if (theme === 'light') {
    document.documentElement.classList.add('light-mode');
  } else {
    document.documentElement.classList.remove('light-mode');
  }
  localStorage.setItem('nexora-theme', theme);
  state.currentTheme = theme;
}

function toggleTheme() {
  const newTheme = state.currentTheme === 'dark' ? 'light' : 'dark';
  applyTheme(newTheme);
  showToast(`Switched to ${newTheme.toUpperCase()} mode`, 'info');
  renderProfile();
}

// Real-Time Countdown Timer for Flash Deals
function initFlashTimer() {
  const hoursEl = document.getElementById('hours');
  const minsEl = document.getElementById('mins');
  const secsEl = document.getElementById('secs');
  
  if (!hoursEl) return;

  // Set target to end of today
  const updateTimer = () => {
    const now = new Date();
    const endOfDay = new Date();
    endOfDay.setHours(23, 59, 59, 999);
    
    const diff = endOfDay - now;
    if (diff <= 0) {
      hoursEl.textContent = '00';
      minsEl.textContent = '00';
      secsEl.textContent = '00';
      return;
    }

    const hours = Math.floor(diff / (1000 * 60 * 60));
    const mins = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    const secs = Math.floor((diff % (1000 * 60)) / 1000);

    hoursEl.textContent = hours.toString().padStart(2, '0');
    minsEl.textContent = mins.toString().padStart(2, '0');
    secsEl.textContent = secs.toString().padStart(2, '0');
  };

  updateTimer();
  setInterval(updateTimer, 1000);
}

// Render Home Screen
function renderAll() {
  renderHomeProducts();
  updateCartBadge();
  updateWishlistBadge();
  updateNotificationsBadge();
}

function renderHomeProducts() {
  // 1. Flash Deals
  const flashDeals = window.NexoraDB.getFlashDeals();
  const flashWrapper = document.getElementById('flash-deals-list');
  if (flashWrapper) {
    flashWrapper.innerHTML = flashDeals.map(p => renderProductCard(p, true)).join('');
  }

  // 2. New Arrivals
  const newArrivals = window.NexoraDB.getNewArrivals();
  const newWrapper = document.getElementById('new-arrivals-list');
  if (newWrapper) {
    newWrapper.innerHTML = newArrivals.map(p => renderProductCard(p)).join('');
  }

  // 3. Trending
  const trending = window.NexoraDB.getTrendingProducts();
  const trendingWrapper = document.getElementById('trending-list');
  if (trendingWrapper) {
    trendingWrapper.innerHTML = trending.map(p => renderProductCard(p)).join('');
  }

  // 4. Recommended
  const recommended = window.NexoraDB.getRecommendedProducts();
  const recommendedWrapper = document.getElementById('recommended-list');
  if (recommendedWrapper) {
    recommendedWrapper.innerHTML = recommended.map(p => renderProductCard(p)).join('');
  }

  // Categories Header horizontal render
  const categoriesWrapper = document.getElementById('categories-list');
  if (categoriesWrapper) {
    categoriesWrapper.innerHTML = window.NexoraDB.CATEGORIES.map(c => `
      <div class="category-item" onclick="selectCategorySearch('${c.id}')">
        <div class="category-icon" style="background-color: ${c.color}">
          <i class="${c.icon}"></i>
        </div>
        <span class="category-name">${c.name}</span>
      </div>
    `).join('');
  }
}

// Standard Product Card Renderer
function renderProductCard(product, showProgress = false) {
  const isWishlisted = state.wishlist.has(product.id);
  const discountedPrice = product.price * (1 - product.discount / 100);
  
  let progressHtml = '';
  if (showProgress && product.flashDealClaimed) {
    progressHtml = `
      <div style="font-size: 9px; color: var(--text-secondary); margin-top: 6px; display: flex; justify-content: space-between;">
        <span>Claimed ${product.flashDealClaimed}%</span>
        <span>${product.stock} left</span>
      </div>
      <div class="claim-progress-bar">
        <div class="claim-progress-fill" style="width: ${product.flashDealClaimed}%"></div>
      </div>
    `;
  }

  return `
    <div class="product-card" onclick="openProductDetail('${product.id}')">
      <div class="card-img-wrapper">
        <img src="${product.images[0]}" alt="${product.name}" loading="lazy">
        ${product.discount > 0 ? `<div class="discount-badge">-${product.discount}%</div>` : ''}
        <button class="wishlist-btn-card ${isWishlisted ? 'active' : ''}" 
                onclick="event.stopPropagation(); toggleWishlist('${product.id}', this)">
          <i class="${isWishlisted ? 'ri-heart-fill' : 'ri-heart-line'}"></i>
        </button>
      </div>
      <div class="card-details">
        <div class="card-title">${product.name}</div>
        <div class="card-rating">
          <i class="ri-star-fill"></i>
          <span>${product.rating} (${product.reviewsCount})</span>
        </div>
        <div class="card-price-row">
          <div>
            <span class="card-price">${formatPrice(discountedPrice)}</span>
            ${product.discount > 0 ? `<span class="card-old-price">${formatPrice(product.price)}</span>` : ''}
          </div>
        </div>
        ${progressHtml}
      </div>
    </div>
  `;
}

// Product Details Screen
function openProductDetail(productId) {
  const product = window.NexoraDB.getProductById(productId);
  if (!product) return;

  state.selectedProduct = product;
  state.activeProductTab = 'description';
  state.activeDetailImageIndex = 0;

  const detailSheet = document.getElementById('product-detail-sheet');
  detailSheet.innerHTML = `
    <div class="modal-header">
      <button class="icon-btn back-btn" onclick="closeAllModals()"><i class="ri-arrow-left-line"></i></button>
      <div class="modal-title">Product Details</div>
      <button class="icon-btn" onclick="shareProduct('${product.name}')"><i class="ri-share-line"></i></button>
    </div>
    
    <div class="modal-body">
      <!-- Media Gallery -->
      <div class="detail-gallery">
        <img id="detail-main-img" src="${product.images[0]}" alt="${product.name}">
        ${product.videoUrl ? `
          <div class="play-badge" onclick="playMockVideo('${product.videoUrl}')">
            <i class="ri-play-fill"></i> Watch Video Demo
          </div>
        ` : ''}
        
        <div class="gallery-dots">
          ${product.images.map((img, idx) => `
            <div class="dot ${idx === 0 ? 'active' : ''}" onclick="changeDetailImage(${idx})"></div>
          `).join('')}
        </div>
      </div>

      <!-- Pricing Row -->
      <div class="detail-price-row">
        <div class="detail-price-block">
          <span class="detail-price">${formatPrice(product.price * (1 - product.discount / 100))}</span>
          ${product.discount > 0 ? `
            <div class="detail-old-price-row">
              <span class="detail-old-price">${formatPrice(product.price)}</span>
              <span class="detail-discount">${product.discount}% OFF</span>
            </div>
          ` : ''}
        </div>
        <div class="detail-stock ${product.stock === 0 ? 'out-of-stock' : ''}">
          ${product.stock > 0 ? `<i class="ri-checkbox-circle-fill"></i> In Stock (${product.stock})` : '<i class="ri-close-circle-fill"></i> Out of Stock'}
        </div>
      </div>

      <!-- Title & Ratings -->
      <div class="detail-title">${product.name}</div>
      
      <div class="detail-rating-row">
        <div class="detail-rating">
          <i class="ri-star-fill"></i>
          <span>${product.rating}</span>
        </div>
        <div class="detail-rating-reviews">${product.reviewsCount} Customer Reviews</div>
      </div>

      <!-- Tabs Navigation -->
      <div class="detail-tabs-nav">
        <div class="detail-tab active" id="tab-desc" onclick="switchProductTab('description')">Description</div>
        <div class="detail-tab" id="tab-specs" onclick="switchProductTab('specifications')">Specifications</div>
        <div class="detail-tab" id="tab-reviews" onclick="switchProductTab('reviews')">Reviews (${product.reviews.length})</div>
      </div>

      <!-- Tab Contents -->
      <div id="content-desc" class="detail-tab-content active">
        <p>${product.description}</p>
      </div>
      
      <div id="content-specs" class="detail-tab-content">
        <table style="width: 100%; border-collapse: collapse; font-size: 13px;">
          ${Object.entries(product.specs).map(([key, val]) => `
            <tr style="border-bottom: 1px solid var(--glass-border);">
              <td style="padding: 10px 0; font-weight: 700; color: var(--text-primary); width: 40%;">${key}</td>
              <td style="padding: 10px 0; color: var(--text-secondary);">${val}</td>
            </tr>
          `).join('')}
        </table>
      </div>
      
      <div id="content-reviews" class="detail-tab-content">
        ${product.reviews.map(r => `
          <div class="review-item">
            <div class="review-user-row">
              <div class="review-user">
                <img src="${r.avatar}" alt="${r.user}">
                <span>${r.user}</span>
              </div>
              <div class="review-rating">
                ${Array(r.rating).fill('<i class="ri-star-fill"></i>').join('')}
              </div>
            </div>
            <div class="review-date">${r.date}</div>
            <div class="review-comment">${r.comment}</div>
          </div>
        `).join('')}
        
        <button class="btn-secondary" style="width: 100%; margin-top: 10px;" onclick="openAddReviewModal()">
          <i class="ri-edit-line"></i> Write a Review
        </button>
      </div>

      <!-- Seller Card -->
      <div class="seller-card">
        <div class="seller-profile">
          <div class="seller-avatar">${product.seller.name.charAt(0)}</div>
          <div>
            <div class="seller-name">${product.seller.name}</div>
            <div class="seller-meta">Joined ${product.seller.joined} | ${product.seller.responseRate} Response Rate</div>
          </div>
        </div>
        <div class="seller-rating">
          <i class="ri-star-fill"></i> ${product.seller.rating} Store Rating
        </div>
      </div>

      <!-- Related Products -->
      <h3 style="font-size: 14px; margin-top: 20px; margin-bottom: 10px;">Related Products</h3>
      <div class="horizontal-products" style="padding-left: 0; padding-right: 0;">
        ${window.NexoraDB.getProductsByCategory(product.category)
          .filter(p => p.id !== product.id)
          .map(p => renderProductCard(p))
          .join('')}
      </div>
    </div>

    <!-- Footer Action Bar -->
    <div class="detail-footer">
      <button class="action-btn-circle ${state.wishlist.has(product.id) ? 'active' : ''}" 
              id="detail-wishlist-btn" onclick="toggleWishlist('${product.id}', this, true)" style="color: ${state.wishlist.has(product.id) ? 'var(--accent-danger)' : 'var(--text-secondary)'}">
        <i class="${state.wishlist.has(product.id) ? 'ri-heart-fill' : 'ri-heart-line'}"></i>
      </button>
      <button class="btn-primary" onclick="addToCart('${product.id}')">
        <i class="ri-shopping-cart-2-line"></i> Add to Cart
      </button>
    </div>
  `;

  detailSheet.classList.add('active');
}

function changeDetailImage(index) {
  if (!state.selectedProduct) return;
  state.activeDetailImageIndex = index;
  
  const imgEl = document.getElementById('detail-main-img');
  if (imgEl) imgEl.src = state.selectedProduct.images[index];
  
  // Dots update
  const dots = document.querySelectorAll('.detail-gallery .dot');
  dots.forEach((dot, idx) => {
    if (idx === index) dot.classList.add('active');
    else dot.classList.remove('active');
  });
}

function switchProductTab(tabName) {
  state.activeProductTab = tabName;
  
  // Update navs
  document.querySelectorAll('.detail-tab').forEach(el => el.classList.remove('active'));
  const activeTabEl = document.getElementById(`tab-${tabName.substring(0, 4)}`);
  if (activeTabEl) activeTabEl.classList.add('active');

  // Update content divs
  document.querySelectorAll('.detail-tab-content').forEach(el => el.classList.remove('active'));
  const activeContentEl = document.getElementById(`content-${tabName.substring(0, 4)}`);
  if (activeContentEl) activeContentEl.classList.add('active');
}

function playMockVideo(videoUrl) {
  const overlay = document.getElementById('video-overlay');
  const video = overlay.querySelector('video');
  video.src = videoUrl;
  overlay.classList.add('active');
  video.play().catch(e => {
    console.log("Auto-play blocked, playing with controls", e);
  });
}

function closeVideoPlayer() {
  const overlay = document.getElementById('video-overlay');
  const video = overlay.querySelector('video');
  video.pause();
  overlay.classList.remove('active');
}

function shareProduct(name) {
  if (navigator.share) {
    navigator.share({
      title: 'Nexora Shopping',
      text: `Check out ${name} on Nexora!`,
      url: window.location.href
    }).catch(console.error);
  } else {
    showToast(`Shared: ${name}`, 'success');
  }
}

// Wishlist Logic
function toggleWishlist(productId, element, fromDetails = false) {
  const isAdded = state.wishlist.has(productId);
  if (isAdded) {
    state.wishlist.delete(productId);
    showToast('Removed from Wishlist', 'info');
    if (element) {
      element.classList.remove('active');
      const icon = element.querySelector('i');
      if (icon) icon.className = 'ri-heart-line';
      if (fromDetails) element.style.color = 'var(--text-secondary)';
    }
  } else {
    state.wishlist.add(productId);
    showToast('Added to Wishlist!', 'success');
    if (element) {
      element.classList.add('active');
      const icon = element.querySelector('i');
      if (icon) icon.className = 'ri-heart-fill';
      if (fromDetails) element.style.color = 'var(--accent-danger)';
    }
  }
  
  updateWishlistBadge();
  if (state.activeTab === 'wishlist') {
    renderWishlist();
  }
}

function updateWishlistBadge() {
  const count = state.wishlist.size;
  const badge = document.getElementById('wishlist-badge');
  if (badge) {
    badge.textContent = count;
    badge.style.display = count > 0 ? 'flex' : 'none';
  }
}

function renderWishlist() {
  const grid = document.getElementById('wishlist-grid');
  if (!grid) return;

  if (state.wishlist.size === 0) {
    grid.innerHTML = `
      <div class="empty-state" style="grid-column: span 2;">
        <i class="ri-heart-line"></i>
        <h3>Your Wishlist is Empty</h3>
        <p>Tap the heart icon on any product to save items here.</p>
        <button class="btn-primary" style="margin-top: 10px;" onclick="switchTab('home')">Start Shopping</button>
      </div>
    `;
    return;
  }

  const wishlistProducts = window.NexoraDB.PRODUCTS.filter(p => state.wishlist.has(p.id));
  grid.innerHTML = wishlistProducts.map(p => renderProductCard(p)).join('');
}

// Cart Logic
function addToCart(productId) {
  const product = window.NexoraDB.getProductById(productId);
  if (!product) return;

  if (product.stock <= 0) {
    showToast('Sorry, this product is out of stock!', 'danger');
    return;
  }

  const existingItem = state.cart.find(item => item.product.id === productId);
  if (existingItem) {
    if (existingItem.quantity >= product.stock) {
      showToast(`Cannot add more. Limit of ${product.stock} items reached.`, 'warning');
      return;
    }
    existingItem.quantity += 1;
  } else {
    state.cart.push({ product, quantity: 1 });
  }

  showToast(`${product.name} added to cart!`, 'success');
  updateCartBadge();
  
  if (state.activeTab === 'cart') {
    renderCart();
  }
}

function updateCartBadge() {
  const count = state.cart.reduce((total, item) => total + item.quantity, 0);
  const badge = document.getElementById('cart-badge');
  if (badge) {
    badge.textContent = count;
    badge.style.display = count > 0 ? 'flex' : 'none';
  }
}

function changeCartQty(productId, delta) {
  const item = state.cart.find(i => i.product.id === productId);
  if (!item) return;

  const newQty = item.quantity + delta;
  if (newQty <= 0) {
    removeCartItem(productId);
    return;
  }

  if (newQty > item.product.stock) {
    showToast(`Sorry, only ${item.product.stock} items are in stock.`, 'warning');
    return;
  }

  item.quantity = newQty;
  renderCart();
  updateCartBadge();
}

function removeCartItem(productId) {
  state.cart = state.cart.filter(item => item.product.id !== productId);
  showToast('Item removed from cart', 'info');
  renderCart();
  updateCartBadge();
}

function renderCart() {
  const cartList = document.getElementById('cart-list');
  const summary = document.getElementById('cart-summary');
  
  if (!cartList || !summary) return;

  if (state.cart.length === 0) {
    cartList.innerHTML = `
      <div class="empty-state">
        <i class="ri-shopping-cart-2-line"></i>
        <h3>Your Cart is Empty</h3>
        <p>Add some products to your cart to begin checkouts.</p>
        <button class="btn-primary" style="margin-top: 10px;" onclick="switchTab('home')">Browse Catalog</button>
      </div>
    `;
    summary.style.display = 'none';
    return;
  }

  summary.style.display = 'flex';
  
  // Render Cart Items
  cartList.innerHTML = state.cart.map(item => {
    const p = item.product;
    const discountedPrice = p.price * (1 - p.discount / 100);
    return `
      <div class="cart-item">
        <img class="cart-item-img" src="${p.images[0]}" alt="${p.name}">
        <div class="cart-item-info">
          <div class="cart-item-title" onclick="openProductDetail('${p.id}')">${p.name}</div>
          <div class="cart-item-price">${formatPrice(discountedPrice)}</div>
          <div class="cart-qty-control">
            <button class="qty-btn" onclick="changeCartQty('${p.id}', -1)">-</button>
            <span class="qty-num">${item.quantity}</span>
            <button class="qty-btn" onclick="changeCartQty('${p.id}', 1)">+</button>
          </div>
        </div>
        <i class="ri-delete-bin-line cart-item-delete" onclick="removeCartItem('${p.id}')"></i>
      </div>
    `;
  }).join('');

  // Calculate totals
  const subtotal = state.cart.reduce((sum, item) => {
    const discPrice = item.product.price * (1 - item.product.discount / 100);
    return sum + (discPrice * item.quantity);
  }, 0);

  let discountAmount = 0;
  if (state.appliedCoupon) {
    const coupon = COUPONS[state.appliedCoupon];
    if (coupon.type === 'percent') {
      discountAmount = subtotal * (coupon.value / 100);
    } else if (coupon.type === 'flat') {
      // Calculate Flat in USD vs LKR conversion
      const flatUSD = state.currency === 'LKR' ? coupon.value / state.exchangeRate : coupon.value;
      discountAmount = Math.min(flatUSD, subtotal);
    }
  }

  const shipping = subtotal > 100 ? 0 : 5.00; // Free shipping over $100
  const finalTotal = subtotal - discountAmount + shipping;

  summary.innerHTML = `
    <div class="coupon-row">
      <input type="text" id="coupon-input" placeholder="Promo code (e.g. NEXORA10)" value="${state.appliedCoupon || ''}" ${state.appliedCoupon ? 'disabled' : ''}>
      ${state.appliedCoupon ? 
        `<button class="btn-secondary" onclick="removeCoupon()">Remove</button>` : 
        `<button class="btn-secondary" onclick="applyCoupon()">Apply</button>`
      }
    </div>
    
    <div class="summary-row">
      <span>Subtotal</span>
      <span>${formatPrice(subtotal)}</span>
    </div>
    ${discountAmount > 0 ? `
      <div class="summary-row discount">
        <span>Coupon Discount (${state.appliedCoupon})</span>
        <span>-${formatPrice(discountAmount)}</span>
      </div>
    ` : ''}
    <div class="summary-row">
      <span>Shipping Fee</span>
      <span>${shipping === 0 ? 'FREE' : formatPrice(shipping)}</span>
    </div>
    <div class="summary-row total">
      <span>Estimated Total</span>
      <span>${formatPrice(finalTotal)}</span>
    </div>
    
    <button class="btn-primary" style="margin-top: 10px; width: 100%;" onclick="openCheckoutModal(${finalTotal})">
      Proceed to Checkout <i class="ri-arrow-right-line"></i>
    </button>
  `;
}

// Coupons Logic
function applyCoupon() {
  const code = document.getElementById('coupon-input').value.toUpperCase().trim();
  if (COUPONS[code]) {
    state.appliedCoupon = code;
    showToast('Promo code applied successfully!', 'success');
    renderCart();
  } else {
    showToast('Invalid Coupon Code!', 'danger');
  }
}

function removeCoupon() {
  state.appliedCoupon = null;
  showToast('Coupon removed', 'info');
  renderCart();
}

// Checkout Modal Logic
function openCheckoutModal(totalPrice) {
  const modal = document.getElementById('checkout-sheet');
  modal.innerHTML = `
    <div class="modal-header">
      <button class="icon-btn back-btn" onclick="closeAllModals()"><i class="ri-arrow-left-line"></i></button>
      <div class="modal-title">Checkout</div>
      <div></div>
    </div>
    <div class="modal-body" style="padding-bottom: 90px;">
      <h3 style="font-size: 15px; margin-bottom: 12px;">Delivery Address</h3>
      <div class="form-group">
        <label>Full Name</label>
        <input type="text" id="checkout-name" value="${state.user.name}">
      </div>
      <div class="form-group">
        <label>Street Address</label>
        <textarea id="checkout-address" rows="2">${state.user.address}</textarea>
      </div>

      <h3 style="font-size: 15px; margin-top: 20px; margin-bottom: 12px;">Payment Method</h3>
      <div class="form-group">
        <select id="checkout-payment">
          <option value="Card" ${state.user.paymentMethod === 'Card' ? 'selected' : ''}>Credit/Debit Card (Visa/Mastercard)</option>
          <option value="Cash" ${state.user.paymentMethod === 'Cash' ? 'selected' : ''}>Cash on Delivery (COD)</option>
          <option value="Koko" ${state.user.paymentMethod === 'Koko' ? 'selected' : ''}>Koko (Buy Now Pay Later)</option>
          <option value="Mintpay" ${state.user.paymentMethod === 'Mintpay' ? 'selected' : ''}>Mintpay (3 Interest-Free Installments)</option>
        </select>
      </div>

      <h3 style="font-size: 15px; margin-top: 20px; margin-bottom: 12px;">Order Summary</h3>
      <div style="background: var(--bg-secondary); border-radius: 16px; padding: 16px; display: flex; flex-direction: column; gap: 8px;">
        ${state.cart.map(item => `
          <div style="display: flex; justify-content: space-between; font-size: 12px;">
            <span style="color: var(--text-primary); text-overflow: ellipsis; white-space: nowrap; overflow: hidden; max-width: 70%;">${item.product.name} (x${item.quantity})</span>
            <span style="font-weight: 700;">${formatPrice(item.product.price * (1 - item.product.discount/100) * item.quantity)}</span>
          </div>
        `).join('')}
        <div style="border-top: 1px solid var(--glass-border); padding-top: 8px; margin-top: 8px; display: flex; justify-content: space-between; font-weight: 800;">
          <span>Total To Pay</span>
          <span style="color: var(--accent-primary);">${formatPrice(totalPrice)}</span>
        </div>
      </div>
    </div>
    <div style="position: absolute; bottom: 0; left: 0; width: 100%; padding: 16px; background: var(--bg-primary); border-top: 1px solid var(--glass-border);">
      <button class="btn-primary" style="width: 100%;" onclick="placeOrder(${totalPrice})">
        Confirm & Place Order (${formatPrice(totalPrice)})
      </button>
    </div>
  `;
  modal.classList.add('active');
}

function placeOrder(totalPrice) {
  const name = document.getElementById('checkout-name').value.trim();
  const address = document.getElementById('checkout-address').value.trim();
  const payment = document.getElementById('checkout-payment').value;

  if (!name || !address) {
    showToast('Please fill out all address details!', 'warning');
    return;
  }

  // Update user default profile values
  state.user.name = name;
  state.user.address = address;
  state.user.paymentMethod = payment;

  const orderId = `NX-${Math.floor(100000 + Math.random() * 900000)}`;
  const newOrder = {
    id: orderId,
    items: [...state.cart],
    total: totalPrice,
    date: new Date().toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' }),
    status: 'ordered', // ordered, processing, shipped, delivered
    trackingIndex: 0 // corresponds to visual stepper
  };

  // Add order to beginning of list
  state.orders.unshift(newOrder);

  // Add notification
  const newNotif = {
    id: `n-${Date.now()}`,
    title: 'Order Confirmed!',
    body: `Your order ${orderId} has been successfully placed. Total paid: ${formatPrice(totalPrice)}.`,
    type: 'order',
    time: 'Just now',
    unread: true
  };
  state.notifications.unshift(newNotif);

  // Clear cart
  state.cart = [];
  state.appliedCoupon = null;
  updateCartBadge();
  updateNotificationsBadge();

  // Show Order Success Screen
  closeAllModals();
  openOrderSuccessModal(orderId);
}

function openOrderSuccessModal(orderId) {
  const modal = document.getElementById('order-success-sheet');
  modal.innerHTML = `
    <div class="modal-body" style="display: flex; flex-direction: column; align-items: center; justify-content: center; text-align: center; height: 100%; gap: 16px;">
      <div style="width: 80px; height: 80px; border-radius: 50%; background: rgba(16, 185, 129, 0.15); color: var(--accent-success); display: flex; align-items: center; justify-content: center; font-size: 40px; animation: popScale var(--transition-normal);">
        <i class="ri-checkbox-circle-fill"></i>
      </div>
      <h2 style="font-size: 22px;">Order Placed Successfully!</h2>
      <p style="color: var(--text-secondary); max-width: 80%;">
        Thank you for shopping with Nexora. Your order ID is <strong style="color: var(--text-primary);">${orderId}</strong>.
      </p>
      <div style="display: flex; flex-direction: column; width: 100%; gap: 10px; margin-top: 20px;">
        <button class="btn-primary" onclick="closeAllModals(); switchTab('profile'); showOrdersList();">
          Track Your Order
        </button>
        <button class="btn-secondary" onclick="closeAllModals(); switchTab('home');">
          Continue Shopping
        </button>
      </div>
    </div>
  `;
  modal.classList.add('active');
}

// Profile Tab Render & Functions
function renderProfile() {
  const pName = document.getElementById('prof-name');
  const pEmail = document.getElementById('prof-email');
  const pAvatar = document.getElementById('prof-avatar');
  const currencyLabel = document.getElementById('prof-currency-label');
  const themeLabel = document.getElementById('prof-theme-label');

  if (pName) pName.textContent = state.user.name;
  if (pEmail) pEmail.textContent = state.user.email;
  if (pAvatar) pAvatar.src = state.user.avatar;
  if (currencyLabel) currencyLabel.textContent = state.currency;
  if (themeLabel) themeLabel.textContent = state.currentTheme.toUpperCase();
}

function toggleCurrency() {
  state.currency = state.currency === 'LKR' ? 'USD' : 'LKR';
  showToast(`Currency changed to ${state.currency}`, 'info');
  renderAll();
  renderProfile();
}

function openEditProfileModal() {
  const modal = document.getElementById('edit-profile-sheet');
  modal.innerHTML = `
    <div class="modal-header">
      <button class="icon-btn back-btn" onclick="closeAllModals()"><i class="ri-arrow-left-line"></i></button>
      <div class="modal-title">Edit Profile</div>
      <div></div>
    </div>
    <div class="modal-body">
      <div class="form-group">
        <label>Full Name</label>
        <input type="text" id="edit-name" value="${state.user.name}">
      </div>
      <div class="form-group">
        <label>Email Address</label>
        <input type="email" id="edit-email" value="${state.user.email}">
      </div>
      <div class="form-group">
        <label>Default Shipping Address</label>
        <textarea id="edit-address" rows="3">${state.user.address}</textarea>
      </div>
      <button class="btn-primary" style="width: 100%; margin-top: 20px;" onclick="saveProfileChanges()">
        Save Changes
      </button>
    </div>
  `;
  modal.classList.add('active');
}

function saveProfileChanges() {
  const name = document.getElementById('edit-name').value.trim();
  const email = document.getElementById('edit-email').value.trim();
  const address = document.getElementById('edit-address').value.trim();

  if (!name || !email || !address) {
    showToast('All fields must be filled!', 'warning');
    return;
  }

  state.user.name = name;
  state.user.email = email;
  state.user.address = address;
  state.user.avatar = `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(name)}`;

  showToast('Profile updated!', 'success');
  closeAllModals();
  renderProfile();
}

// Orders Tracker Views
function showOrdersList() {
  const modal = document.getElementById('orders-history-sheet');
  modal.innerHTML = `
    <div class="modal-header">
      <button class="icon-btn back-btn" onclick="closeAllModals()"><i class="ri-arrow-left-line"></i></button>
      <div class="modal-title">My Orders</div>
      <div></div>
    </div>
    <div class="modal-body" id="orders-history-body">
      <!-- Dynamic list -->
    </div>
  `;
  
  renderOrdersHistoryBody();
  modal.classList.add('active');
}

function renderOrdersHistoryBody() {
  const body = document.getElementById('orders-history-body');
  if (!body) return;

  if (state.orders.length === 0) {
    body.innerHTML = `
      <div class="empty-state">
        <i class="ri-archive-line"></i>
        <h3>No Orders Placed Yet</h3>
        <p>Your order tracking logs will appear here once you place a purchase.</p>
        <button class="btn-primary" style="margin-top: 10px;" onclick="closeAllModals(); switchTab('home');">Explore Shop</button>
      </div>
    `;
    return;
  }

  body.innerHTML = state.orders.map(order => {
    // Stepper logic
    const steps = ['Ordered', 'Processing', 'Shipped', 'Delivered'];
    const currentIdx = order.trackingIndex;

    const stepperHtml = steps.map((step, idx) => {
      let statusClass = '';
      if (idx < currentIdx) statusClass = 'completed';
      else if (idx === currentIdx) statusClass = 'active';
      return `
        <div class="tracking-step ${statusClass}">
          <div class="step-dot">
            ${idx < currentIdx ? '<i class="ri-check-line" style="color: white; font-size: 8px;"></i>' : ''}
          </div>
          <span class="step-label">${step}</span>
        </div>
      `;
    }).join('');

    return `
      <div class="order-item">
        <div class="order-header">
          <div>
            <div class="order-id">${order.id}</div>
            <div class="order-date">${order.date}</div>
          </div>
          <div>
            <span class="order-status ${order.status}">${order.status.toUpperCase()}</span>
          </div>
        </div>
        
        <div style="font-size: 12px; color: var(--text-secondary); margin-bottom: 8px;">
          Items: ${order.items.map(i => `${i.product.name} (x${i.quantity})`).join(', ')}
        </div>
        <div style="font-size: 13px; font-weight: 800; color: var(--text-primary);">
          Paid: <span style="color: var(--accent-primary);">${formatPrice(order.total)}</span>
        </div>
        
        <!-- Live Track Stepper -->
        <div class="tracking-stepper">
          ${stepperHtml}
        </div>
      </div>
    `;
  }).join('');
}

// Simulate Order Status Progress (Makes the app feel extremely alive!)
function initSimulatedOrderUpdates() {
  setInterval(() => {
    // Look for orders that are not 'delivered'
    const pendingOrders = state.orders.filter(o => o.status !== 'delivered');
    if (pendingOrders.length === 0) return;

    // Pick one randomly to progress
    const randomOrder = pendingOrders[Math.floor(Math.random() * pendingOrders.length)];
    const statusSequence = ['ordered', 'processing', 'shipped', 'delivered'];
    const currentIdx = statusSequence.indexOf(randomOrder.status);
    
    if (currentIdx < statusSequence.length - 1) {
      const nextStatus = statusSequence[currentIdx + 1];
      randomOrder.status = nextStatus;
      randomOrder.trackingIndex = currentIdx + 1;

      // Add Notification
      const titles = {
        'processing': 'Order Packed!',
        'shipped': 'Order Dispatched!',
        'delivered': 'Order Delivered!'
      };
      const bodies = {
        'processing': `Your order ${randomOrder.id} is now packed and being processed.`,
        'shipped': `Out for delivery! Your order ${randomOrder.id} has been handed over to our courier partner.`,
        'delivered': `Order Delivered! Your package under ${randomOrder.id} was successfully delivered.`
      };

      const newNotif = {
        id: `n-${Date.now()}`,
        title: titles[nextStatus],
        body: bodies[nextStatus],
        type: 'order',
        time: 'Just now',
        unread: true
      };

      state.notifications.unshift(newNotif);
      updateNotificationsBadge();
      showToast(`${titles[nextStatus]} for ${randomOrder.id}`, 'info');

      // Refresh order view if open
      if (document.getElementById('orders-history-sheet')?.classList.contains('active')) {
        renderOrdersHistoryBody();
      }
      
      if (state.activeTab === 'notifications') {
        renderNotifications();
      }
    }
  }, 40000); // Check and progress status every 40 seconds
}

// Notifications Logic
function updateNotificationsBadge() {
  const unreadCount = state.notifications.filter(n => n.unread).length;
  const badge = document.getElementById('notif-badge');
  if (badge) {
    badge.textContent = unreadCount;
    badge.style.display = unreadCount > 0 ? 'flex' : 'none';
  }
}

function renderNotifications() {
  const list = document.getElementById('notif-list');
  if (!list) return;

  if (state.notifications.length === 0) {
    list.innerHTML = `
      <div class="empty-state">
        <i class="ri-notification-3-line"></i>
        <h3>No Notifications</h3>
        <p>Promotions and updates about your orders will be listed here.</p>
      </div>
    `;
    return;
  }

  list.innerHTML = state.notifications.map(n => {
    let iconClass = 'ri-notification-3-line';
    if (n.type === 'promo') iconClass = 'ri-percent-line';
    if (n.type === 'order') iconClass = 'ri-truck-line';

    return `
      <div class="notif-item ${n.unread ? 'unread' : ''} ${n.type}" onclick="markNotifRead('${n.id}')">
        <div class="notif-icon ${n.type}">
          <i class="${iconClass}"></i>
        </div>
        <div class="notif-content">
          <div class="notif-title">${n.title}</div>
          <div class="notif-body">${n.body}</div>
          <div class="notif-time">${n.time}</div>
        </div>
      </div>
    `;
  }).join('');
}

function markNotifRead(notifId) {
  const notif = state.notifications.find(n => n.id === notifId);
  if (notif && notif.unread) {
    notif.unread = false;
    updateNotificationsBadge();
    renderNotifications();
  }
}

function markAllNotificationsRead() {
  state.notifications.forEach(n => n.unread = false);
  updateNotificationsBadge();
  renderNotifications();
  showToast('All notifications marked as read', 'success');
}

// Search Logic
function initSearch() {
  const searchInput = document.getElementById('search-input');
  if (!searchInput) return;

  searchInput.addEventListener('input', (e) => {
    const query = e.target.value;
    performSearch(query);
  });
}

function selectCategorySearch(catId) {
  switchTab('search');
  const cat = window.NexoraDB.CATEGORIES.find(c => c.id === catId);
  
  // Set values
  const searchInput = document.getElementById('search-input');
  if (searchInput) searchInput.value = cat ? cat.name : '';
  
  performSearch('', catId);
}

function renderSearchScreen() {
  // Pre-fill categories in the selection bar inside search screen
  const headerCat = document.getElementById('search-categories-filter');
  if (headerCat) {
    headerCat.innerHTML = `
      <span class="search-cat-chip active" onclick="filterSearchByCat(this, 'all')">All</span>
      ${window.NexoraDB.CATEGORIES.map(c => `
        <span class="search-cat-chip" onclick="filterSearchByCat(this, '${c.id}')">${c.name}</span>
      `).join('')}
    `;
  }
  performSearch('');
}

let activeSearchCategory = 'all';

function filterSearchByCat(chipEl, catId) {
  document.querySelectorAll('.search-cat-chip').forEach(c => c.classList.remove('active'));
  chipEl.classList.add('active');
  
  activeSearchCategory = catId;
  const searchInput = document.getElementById('search-input');
  const query = searchInput ? searchInput.value : '';
  
  performSearch(query, catId === 'all' ? null : catId);
}

function performSearch(query, categoryId = null) {
  const resultsGrid = document.getElementById('search-results-grid');
  if (!resultsGrid) return;

  const targetCat = categoryId || (activeSearchCategory === 'all' ? null : activeSearchCategory);
  
  const queryLower = query.toLowerCase().trim();
  
  const results = window.NexoraDB.PRODUCTS.filter(p => {
    const matchesQuery = p.name.toLowerCase().includes(queryLower) || p.description.toLowerCase().includes(queryLower);
    const matchesCategory = targetCat ? p.category === targetCat : true;
    return matchesQuery && matchesCategory;
  });

  if (results.length === 0) {
    resultsGrid.innerHTML = `
      <div class="empty-state" style="grid-column: span 2;">
        <i class="ri-search-line"></i>
        <h3>No Products Found</h3>
        <p>We couldn't find matches for "${query}". Try searching other keywords.</p>
      </div>
    `;
    return;
  }

  resultsGrid.innerHTML = results.map(p => renderProductCard(p)).join('');
}

// Add Review Modal Mock implementation
function openAddReviewModal() {
  if (!state.selectedProduct) return;
  const modal = document.getElementById('add-review-sheet');
  modal.innerHTML = `
    <div class="modal-header">
      <button class="icon-btn back-btn" onclick="closeAllModals()"><i class="ri-arrow-left-line"></i></button>
      <div class="modal-title">Write a Review</div>
      <div></div>
    </div>
    <div class="modal-body">
      <div class="form-group">
        <label>Your Rating</label>
        <select id="new-review-rating">
          <option value="5">5 Stars - Excellent</option>
          <option value="4">4 Stars - Very Good</option>
          <option value="3">3 Stars - Good</option>
          <option value="2">2 Stars - Fair</option>
          <option value="1">1 Star - Poor</option>
        </select>
      </div>
      <div class="form-group">
        <label>Comments</label>
        <textarea id="new-review-comment" rows="4" placeholder="Share your experience with this product..."></textarea>
      </div>
      <button class="btn-primary" style="width: 100%; margin-top: 20px;" onclick="submitProductReview()">
        Submit Review
      </button>
    </div>
  `;
  modal.classList.add('active');
}

function submitProductReview() {
  const rating = parseInt(document.getElementById('new-review-rating').value);
  const comment = document.getElementById('new-review-comment').value.trim();

  if (!comment) {
    showToast('Please type a comment for your review!', 'warning');
    return;
  }

  const newReview = {
    user: state.user.name,
    rating: rating,
    date: new Date().toISOString().split('T')[0],
    comment: comment,
    avatar: state.user.avatar
  };

  // Add review to products
  state.selectedProduct.reviews.unshift(newReview);
  // Recalculate ratings
  const totalRating = state.selectedProduct.reviews.reduce((sum, r) => sum + r.rating, 0);
  state.selectedProduct.rating = parseFloat((totalRating / state.selectedProduct.reviews.length).toFixed(1));
  state.selectedProduct.reviewsCount += 1;

  showToast('Thank you! Review submitted.', 'success');
  
  // Re-open detail view to refresh details screen
  openProductDetail(state.selectedProduct.id);
  // Switch to review tab
  switchProductTab('reviews');
}
